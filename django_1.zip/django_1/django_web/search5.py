from django.shortcuts import render
from django.views.decorators import csrf

def search_post(request):
    ctx = {}
    if request.POST:
        def inch_cm(inch):
            return inch*2.54
        def kuzhuang_cm(kuzhuang):
            return (kuzhuang-26+1.9)*2.54
        def lb_g(lb):
            return lb*454
        def pint_ml(pint):
            return pint*473
        def f_c(f):
            return 5/9*f
        inch=request.POST['A']
        kuzhuang=request.POST['B']
        lb=request.POST['C']
        pint = request.POST['D']
        f=request.POST['E']
        if(float(inch) >= 0 and 26<=int(kuzhuang)<=54 and float(lb)>=0 and float(pint)>=0):
            ctx['a']=str("%f 英尺 = %f 厘米" %(float(inch),float(inch_cm(float(inch)))))
            ctx['b'] = str("%d = %f 厘米腰围" %(int(kuzhuang),float(kuzhuang_cm(int(kuzhuang)))))
            ctx['c'] = str("%f 磅 = %f 克" %(float(lb),float(lb_g(float(lb)))))
            ctx['d'] = str("%f 品脱 = %f 毫升" %(float(pint),float(pint_ml(float(pint)))))
            ctx['e'] = str("%f 华氏度 = %f 摄氏度" %(float(pint),float(f_c(float(f)))))
        else:
            ctx['rlt']=str("输入的数据有误，请重新输入")
    return render(request, "typechange.html", ctx)