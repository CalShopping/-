from django.shortcuts import render
from django.views.decorators import csrf

def search_post(request):
    ctx = {}
    if request.POST:
        def cloth(temperature):
            if (temperature >= 26):
                return "T恤衫"
            else:
                cloth_choice = ["薄款棉毛衫", "厚款棉毛衫", "抓绒衣薄外套", "厚羊毛衫+棉背心", "稍厚棉外套", "薄款羽绒服", "厚款羽绒服"]
                cloth_temperature = [1, 2, 3, 4, 5, 6, 9]
                cloth_selection = []
                remainder = 26 - temperature
                while remainder != 0:
                    for i in range(7):
                        if remainder >= cloth_temperature[6 - i]:
                            cloth_selection.append(cloth_choice[6 - i])
                            remainder = remainder - cloth_temperature[6 - i]
                            break
                        i = i + 1
                return cloth_selection
        temperature = int(request.POST['tem'])
        ctx['rlt'] = str("建议您穿： %s" %cloth(temperature))
    return render(request, "clothes.html", ctx)