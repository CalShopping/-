# -*- coding: utf-8 -*-

from django.shortcuts import render
from django.views.decorators import csrf


# 接收POST请求数据
def search_post(request):
    ctx = {}
    if request.POST:
        def aa(a, b, discount_before, discoount_after, discount_rate):
            if (a == 0 and b == 0):
                return 0, 0
            else:
                if (discount_before != 0 or discount_after != 0):
                    if ((a + b) >= discount_before):
                        quo = int((a + b) / discount_before)
                        sum = (a + b) - quo * discoount_after
                    else:
                        sum = a + b
                    a_after = a / (a + b) * (sum * discount_rate / 10)
                    b_after = b / (a + b) * (sum * discount_rate / 10)
                    return str("A折后需要付： %f 元，B折后需要付： %f 元" %(a_after,b_after))
                else:
                    sum = a + b
                    a_after = a / (a + b) * (sum * discount_rate / 10)
                    b_after = b / (a + b) * (sum * discount_rate / 10)
                    return str("A折后需要付： %f 元，B折后需要付： %f 元" %(a_after, b_after))
        a=float(request.POST['A'])
        b=float(request.POST['B'])
        discount_before=float(request.POST['C'])
        discount_after = float(request.POST['D'])
        discount_rate=float(request.POST['E'])
        if (a >= 0 and b >= 0 and discount_before >= discount_after and 0 < discount_rate <= 10):
            ctx['rlt'] = aa(a, b, discount_before, discount_after, discount_rate)
        else:
            ctx['rlt'] = str("输入的数据有误，请重新输入")
    return render(request, "AA.html", ctx)