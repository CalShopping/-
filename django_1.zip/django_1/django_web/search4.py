from django.shortcuts import render
from django.views.decorators import csrf

def search_post(request):
    ctx = {}
    if request.POST:
        def discount(money, discount_before, discoount_after, discount_rate):
            new_money = []
            new_args = []
            sum = 0
            new_sum=0
            total=0
            for i in range(len(money)):
                new_money.append(int(money[i]))
                sum = sum + int(money[i])
            if sum == 0:
                return 0
            else:
                if (discount_before != 0 or discount_after != 0):
                    if (sum >= discount_before):
                        quo = int(sum / discount_before)
                        new_sum = sum - quo * discoount_after
                        for i in range(len(new_money)):
                            new_args.append(new_money[i] / sum * (new_sum * discount_rate / 10))
                        for i in range(len(new_args)):
                            total=total+int(new_args[i])
                        return total
                    else:
                        for i in range(len(new_money)):
                            new_args.append(new_money[i] / sum * (sum * discount_rate / 10))
                        for i in range(len(new_args)):
                            total=total+int(new_args[i])
                        return total
                else:
                    for i in range(len(new_money)):
                        new_args.append(new_money[i] / sum * (sum * discount_rate / 10))
                    for i in range(len(new_args)):
                        total = total + int(new_args[i])
                    return total
        discount_before = float(request.POST['full_money'])
        discount_after = float(request.POST['decrease_money'])
        discount_rate = float(request.POST['discount_number'])
        money = request.POST['money'].split()
        flag = 0
        for i in range(len(money)):
            if (int(money[i]) >= 0):
                flag = 0
            else:
                flag = flag + 1
        if (flag == 0 and discount_before >= discount_after and 0 < discount_rate <= 10):
            ctx['rlt'] = str("您实际需要支付的金额为： %f 元" %discount(money, discount_before, discount_after, discount_rate))
        else:
            ctx['rlt'] = str("输入的数据有误，请重新输入")
    return render(request, "discount.html", ctx)