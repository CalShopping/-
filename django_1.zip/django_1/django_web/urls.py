from django.contrib import admin
from django.urls import path
from . import views,search2,search3,search4,search5

urlpatterns={
    path("",views.index),
    path("index.html",views.index),
    path("calculator.html",views.calculator),
    path("shopping.html",views.shopping),
    path("countdown.html",views.countdown),
    path("typechange.html",views.typechange),
    path("AA.html",views.AA),
    path("clothes.html",views.clothes),
    path("discount.html",views.discount),
    path("contact.html",views.contactus),
    path("search-post", search2.search_post),
    path("search_temperature",search3.search_post),
    path("search_discount",search4.search_post),
    path("search_typechange",search5.search_post),
}