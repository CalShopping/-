from django.shortcuts import render

# Create your views here.
def index(request):
    # context= {
    #
    # }
    return render(request,"index.html")



def calculator(request):
    # context = {
    #
    # }
    return render(request, "calculator.html")

def shopping(request):
    return render(request,"shopping.html")

def countdown(request):
    return render(request,"countdown.html")

def typechange(request):
    return render(request,"typechange.html")

def AA(request):
    return render(request,"AA.html")

def clothes(request):
    return render(request,"clothes.html")

def discount(request):
    return render(request,"discount.html")

def contactus(request):
    return render(request, "contact.html")
